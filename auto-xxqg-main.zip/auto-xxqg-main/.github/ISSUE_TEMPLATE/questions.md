---
name: Questions
about: Ask questions if you have any.
title: I have a question
labels: question
assignees: ''

---

1. If you have any questions, you can ask here and wait for the answers.
2. You can also post files or screenshots if it is related to the question.
